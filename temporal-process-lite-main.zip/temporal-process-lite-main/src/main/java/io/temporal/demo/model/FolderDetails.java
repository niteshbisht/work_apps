package io.temporal.demo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FolderDetails {
    private String attachedFolderName;
    private String transactionType;
    private boolean allDocs;
}
