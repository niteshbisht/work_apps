package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TimerConfig {
    @JsonProperty("escalationRejectPeriod")
    private long escalationRejectPeriod;
    @JsonProperty("duein")
    private int dueIn;
    @JsonProperty("dueDateService")
    private String dueDateService;
    @JsonProperty("isDueDateCalculationRequired")
    private boolean isDueDateCalculationRequired;
    @JsonProperty("isLastBusinessDayDueIn")
    private boolean isLastBusinessDayDueIn;
    @JsonProperty("isExpirationSameAsDueDate")
    private boolean isExpirationSameAsDueDate;
    @JsonProperty("expirationService")
    private String expirationService;
    @JsonProperty("randomizeExpirationBy")
    private int randomizeExpirationBy;
    @JsonProperty("dueDateTimeSchedule")
    private String dueDateTimeSchedule;
    @JsonProperty("escalationMetaData")
    private EscalationMetadata escalationMetadata;
}
