package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Action {
    @JsonProperty("stepid")
    private String stepId;
    @JsonProperty("initialStatus")
    private String initialStatus;
    @JsonProperty("initialStepName")
    private String initialStepName;
    @JsonProperty("isNewApprovalProcessFlow")
    private boolean isNewApprovalProcessFlow;
    @JsonProperty("isEmailNotifyFlow")
    private boolean isEmailNoifyFlow;
    @JsonProperty("notificationType")
    private String notificationType;
    @JsonProperty("config")
    private ActionConfig config;
}
