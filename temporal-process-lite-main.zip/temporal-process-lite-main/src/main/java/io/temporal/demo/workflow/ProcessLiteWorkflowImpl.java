package io.temporal.demo.workflow;

import io.temporal.demo.common.Constants;
import io.temporal.demo.model.*;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.CancellationScope;
import io.temporal.workflow.CompletablePromise;
import io.temporal.workflow.Promise;
import io.temporal.workflow.Workflow;

import org.slf4j.Logger;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@WorkflowImpl( taskQueues = Constants.TASK_QUEUE )
public class ProcessLiteWorkflowImpl implements ProcessLiteWorkflow {

    private static final Logger log = Workflow.getLogger(ProcessLiteWorkflowImpl.class);

    // Define the types of events that we need to process
    enum EventTypes
    {
        WORKFLOW_SIGNALED,
        ESCALATION_TIMER_FIRED,
        DUE_IN_TIMER_FIRED
    }

    // constants used to identify task types
    private static final String HUMAN_TASK_TYPE = "HUMAN";
    private static final String SYSTEM_TASK_TYPE = "SYSTEM";

    // constant used to identify the Escalation Reject UI Action
    private static final String ESCALATION_REJECT = "ESCALATIONREJECT";

    // Store the current workflow configuration for easier access
    private WorkflowConfiguration workflowConfig;

    // Promises used to handle the different types of events
    // This includes the workflow being "signaled" (updated),
    // an escalation timer
    // and a due timer
    private CompletablePromise<Void> workflowSignaled;
    Promise<Void> escalationTimer = null;
    Promise<Void> dueTimer = null;

    // Stores the value of the human action (e.g. APPROVE, REJECT, etc)
    private String incomingHumanAction = "";

    // index that points the the current action
    private int currentActionIndex = 0;
    // Identifies what event fired (e.g. workflow signaled, escalation or due timer)
    private EventTypes currentEventType;

    // Workflow entrypoint
    @Override
    public String execute(WorkflowConfiguration workflowConfiguration) {
        log.info("Processing the workflow. appId {}, category {}, subcategory {} ",
                workflowConfiguration.getAppId(),
                workflowConfiguration.getCategory(),
                workflowConfiguration.getSubcategory());

        // Save the workflow configuration
        this.workflowConfig = workflowConfiguration;
        boolean done = false;

        // This really isn't needed -- feel free to remove
        Workflow.sleep(Duration.ofSeconds(1));

        // figure out where this workflow starts at
        currentActionIndex = findInitialActionIndex();

        // The workflow isn't complete until we reach a terminal step
        while (!done)
        {
            log.info("Current action index is {}", currentActionIndex);

            // Retrieve the current action
            Action currentAction = workflowConfiguration.getProcessLiteConfig().getActions().get(currentActionIndex);

            // Process the current action. Returns a boolean to indicate whether this is a terminal step or not
            done = processStep(currentAction);
            if (!done)
            {
                // if we're not at a terminal step, then
                // build our list of promises which are
                // comprised of a signal handler, dueTimer (if set) and escalation Timer (if set)
                List<Promise<Void>> promiseList = new ArrayList<>();

                CancellationScope scope = Workflow.newCancellationScope(
                        () -> {
                            buildPromiseList(promiseList, currentAction);
                        }
                );

                log.info("Starting cancellation scope");
                scope.run();

                log.info("Waiting for the promise(s) to complete.");
                Promise.anyOf(promiseList).get();

                log.info("Ending cancellation scope");
                // This cancels the other promises that didn't fire
                scope.cancel();

                log.info("One of the promises completed!");

                // figure out what promise fired and process it
                processPromise(currentAction);

                log.info("After processing the promise");
            }
        }

        log.info("End of the workflow.");

        return "success";
    }

    /**
     * buildPromiseList - builds a list of promises that the workflow needs to wait
     * @param currentAction - the current action
     */
    private void buildPromiseList(List<Promise<Void>> promiseList, Action currentAction)
    {
        // retrieve the Timer Config as it has data we need to look at
        TimerConfig currentActionTimerConfig = currentAction.getConfig().getTimerConfig();
        long escalationRejectPeriod = currentActionTimerConfig.getEscalationRejectPeriod();
        // clear the promise
        escalationTimer = null;
        if (escalationRejectPeriod > 0) {
            // We have an escalation reject period that needs to be added
            log.info("Escalation Reject Period is {}", escalationRejectPeriod);
            escalationTimer = Workflow.newTimer(Duration.ofSeconds(escalationRejectPeriod));
            escalationTimer.thenApply( (v) -> {
                // this method is called when the timer has fired
                log.info("Escalation Timer fired!");
                // set the currentEventType to match this timer
                this.currentEventType = EventTypes.ESCALATION_TIMER_FIRED;
                return null; } );
            promiseList.add(escalationTimer);
        }

        // clear the due timer
        dueTimer = null;
        if (currentActionTimerConfig.isDueDateCalculationRequired()) {
            // we need to add a Due In timer
            int dueIn = currentActionTimerConfig.getDueIn();
            log.info("Due Date Calculation Required {} hours", dueIn);
            // unit of measure is hours
            dueTimer = Workflow.newTimer(Duration.ofHours(currentActionTimerConfig.getDueIn()));
            dueTimer.thenApply( (v) -> {
                // this method is called when the timer fires
                log.info("Due Timer fired!");
                // set the current event type to this timer
                this.currentEventType = EventTypes.DUE_IN_TIMER_FIRED;
                return null;
            });
            promiseList.add(dueTimer);
        }

        // add in signal promise
        log.info("Creating signal promise");
        workflowSignaled = Workflow.newPromise();
        workflowSignaled.thenApply( (v) -> {
            // this event gets called from within the update handler
            // indicating a signal has been set
            log.info("Workflow has been signaled!");
            // set the current event type to indicate the workflow has been signaled
            this.currentEventType = EventTypes.WORKFLOW_SIGNALED;
            return null; } );

        promiseList.add(workflowSignaled);
    }

    /**
     * processStep - looks at the current action and determines how to handle it
     * @param currentAction - the current action
     * @return a boolean that indicates we are at a terminal step (true) - or not
     */
    private boolean processStep(Action currentAction)
    {
        boolean isDone = false;
        ActionConfig config = currentAction.getConfig();
        String taskType = config.getTaskType();
        log.info("Processing step {} name {} task type {}", currentAction.getStepId(),
                config.getStepName(), config.getTaskType());

        if (HUMAN_TASK_TYPE.equals(taskType))
        {
            log.info("Waiting for human to interact with workflow");
            // nothing to do as we are waiting for an interaction

        } else if (SYSTEM_TASK_TYPE.equals(taskType))
        {
            log.info("System processing task {}", config.getStepName());
            // We need to take some system action
            // TODO: probably need additional logic in here to call activities based on the task
            // are we at the last step?
            isDone = config.getUiActions().isEmpty();
            log.info("At a terminal step? {}, {}", isDone, config.getStepName());
            if (!isDone)
            {
                // pick one of the routes --
                // for now we'll hard code this to "Success"
                // unclear what would cause us to go down the "Cancel"led path
                // Assumption here is that the result of a system activity drives this decision.
                // TODO: figure out how this works and implement this

                // find the next action
                UIAction nextAction = findUIAction(currentAction, "Success");

                // now execute the next action
                takeAction(nextAction);

                // Set the current action and Index to be the next one
                currentActionIndex = findNextActionIndex(nextAction.getStepId());
                currentAction = workflowConfig.getProcessLiteConfig().getActions().get(currentActionIndex);

                // Call processStep with the current action
                // Note that this is recursive -- might be a better way to implement this
                isDone = processStep(currentAction);
            }
        }
        else
        {
            throw new IllegalArgumentException("Unsupported/unhandled task type: " + taskType);
        }

        return isDone;
    }

    /**
     * processPromise determines which event fired
     * @param currentAction - the current action
     */
    private void processPromise(Action currentAction)
    {
        // handle the event that fired
        UIAction nextAction = null;

        switch(currentEventType)
        {
            case WORKFLOW_SIGNALED:
                // handle workflow being signaled
                log.info("The workflow has been signaled with {}", this.incomingHumanAction);

                // set up another promise for future signals
                workflowSignaled = Workflow.newPromise();
                workflowSignaled.thenApply( (v) -> {
                    currentEventType = EventTypes.WORKFLOW_SIGNALED;
                    return null;
                });

                // we know the signal is a valid
                // (because we're using an update with validator)
                // figure out what to do next
                nextAction = findUIAction(currentAction, this.incomingHumanAction);
                takeAction(nextAction);

                // now "advance to the next action"
                currentActionIndex = findNextActionIndex(nextAction.getStepId());

                break;
            case ESCALATION_TIMER_FIRED:
                // handle escalation path
                log.info("The escalation timer has fired!");

                // find the UI action with ESCALATION_REJECT
                nextAction = findUIAction(currentAction, ESCALATION_REJECT);
                takeAction(nextAction);
                currentActionIndex = findNextActionIndex(nextAction.getStepId());

                break;
            case DUE_IN_TIMER_FIRED:
                // otherwise the due timer fired
                log.info("The due timer fired");

                // TODO: handle the due timer condition
                break;
            default:
                // should never get in here, but just in case, raise an exception
                throw new IllegalStateException("Unknown/unhandled promise fired.");
        }
    }

    /***
     * signalWorkflow - Incoming Temporal Update Handler
     * @param incomingAction - the incoming action sent to the workflow
     * @return the action that was signaled
     */
    @Override
    public String signalWorkflow(String incomingAction) {
        log.info("Workflow was signaled {}", incomingAction);
        // store the action
        this.incomingHumanAction = incomingAction;
        // and complete the promise
        workflowSignaled.complete(null);
        return incomingAction;
    }

    /***
     * validateAction - This is the Update Handler's validate method, which is used to make sure
     *                  that the incomingAction passed in is valid (e.g. in the list of UI Actions)
     * @param incomingAction - the incoming action that needs to be validated
     */
    @Override
    public void validateAction(String incomingAction) {
        Action currentAction = workflowConfig.getProcessLiteConfig().getActions().get(currentActionIndex);
        if (!isValidAction(currentAction,incomingAction))
        {
            String validActions = buildListOfValidActions(currentAction);
            String errorMessage = String.format("Invalid incomingAction %s. Valid actions %s", incomingAction, validActions);
            log.error(errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * takeNextAction Process the next action
     * @param uiAction - the UI action to handle
     */
    private void takeAction(UIAction uiAction)
    {
        log.info("Next action: StepID {}, Status {}, Step Name {}, Audit Message {}",
                uiAction.getStepId(),
                uiAction.getStatus(),
                uiAction.getStepName(),
                uiAction.getAuditMessage());

        // "process" this event, likely calling activities when appropriate
        // TODO: Implement this
    }

    /***
     * buildListOfValidActions - returns a string of valid UI actions for a specific action
     * @param currentAction - current action
     * @return - a string that contains all the valid actions
     */
    private String buildListOfValidActions(Action currentAction)
    {
        StringBuilder returnValue = new StringBuilder();
        List<UIAction> actions = currentAction.getConfig().getUiActions();
        for (UIAction uiAction : actions)
        {
            returnValue.append(", ").append(uiAction.getAction());
        }

        return returnValue.toString();
    }

    /***
     * findInitialActionIndex - locates the first Action for the workflow
     * @return an index to the first action
     */
    private int findInitialActionIndex()
    {
        ProcessLiteConfig config = workflowConfig.getProcessLiteConfig();
        String intialStepName = config.getInitialStepName();
        for(int i=0;i<config.getActions().size();i++ )
        {
            Action action = workflowConfig.getProcessLiteConfig().getActions().get(i);

            if (intialStepName.equals(action.getConfig().getStepName()))
            {
                return i;
            }
        }

        throw new IllegalStateException("Unable to find initial action with name " +  intialStepName);
    }

    /***
     * findNextActionIndex - finds the action index for the given stepId
     * @param stepId - what step ID to find
     * @return an index to the action
     */
    private int findNextActionIndex(String stepId)
    {
        if (stepId == null || stepId.isEmpty())
            throw new IllegalArgumentException("StepId cannot be null or empty");

        ProcessLiteConfig config = workflowConfig.getProcessLiteConfig();
        for(int i=0;i<config.getActions().size();i++ )
        {
            Action action = workflowConfig.getProcessLiteConfig().getActions().get(i);
            if (stepId.equals(action.getStepId()))
            {
                return i;
            }
        }

        throw new IllegalStateException("Unable to find next action with id " + stepId);
    }

    /***
     * findUIAction - locates the UI Action for the given actionToTake
     * @param currentAction - the current actionToTake
     * @param actionToTake - the actionToTake that needs to be taken
     * @return - the UI actionToTake that corresponds to the a
     */
    private UIAction findUIAction(Action currentAction, String actionToTake)
    {
        if (actionToTake == null || actionToTake.isEmpty())
            return null;

        List<UIAction> uiActions = currentAction.getConfig().getUiActions();
        for (UIAction uiAction : uiActions)
        {
            if (actionToTake.equals(uiAction.getAction()))
                return uiAction;
        }

        return null;
    }

    /***
     * isValidAction determines if the uiActionToTake is valid for the current uiActionToTake
     * @param currentAction - the current uiActionToTake
     * @param uiActionToTake - the uiActionToTake to be taken
     * @return whether the uiActionToTake is valid or not
     */
    private boolean isValidAction(Action currentAction, String uiActionToTake)
    {
        log.info("checking to see if uiActionToTake {} is valid for Step {}", uiActionToTake, currentAction.getStepId());
        return (findUIAction(currentAction, uiActionToTake) != null);
    }
}
