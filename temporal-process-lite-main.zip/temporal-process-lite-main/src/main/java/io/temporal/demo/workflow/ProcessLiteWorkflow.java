package io.temporal.demo.workflow;

import io.temporal.demo.model.WorkflowConfiguration;
import io.temporal.workflow.UpdateMethod;
import io.temporal.workflow.UpdateValidatorMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface ProcessLiteWorkflow {
    @WorkflowMethod
    String execute(WorkflowConfiguration workflowConfiguration);

    @UpdateMethod
    String signalWorkflow(String action);

    @UpdateValidatorMethod(updateName = "signalWorkflow")
    void validateAction(String action);
}
