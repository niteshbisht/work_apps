package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowConfiguration {
    @JsonProperty("configid")
    private int configId;
    @JsonProperty("appId")
    private String appId;
    @JsonProperty("category")
    private String category;
    @JsonProperty("subcategory")
    private String subcategory;
    @JsonProperty("config")
    private ProcessLiteConfig processLiteConfig;
}
