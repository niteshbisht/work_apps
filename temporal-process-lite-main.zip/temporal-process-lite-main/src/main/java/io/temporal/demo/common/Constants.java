package io.temporal.demo.common;

public class Constants {
    public static final String TASK_QUEUE = "DslTaskQueue";
    public static final String WORKFLOW_ID = "HelloProcessLite";
}
