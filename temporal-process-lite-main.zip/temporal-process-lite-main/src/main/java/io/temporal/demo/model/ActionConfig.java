package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActionConfig {
    @JsonProperty("rolesForTeam")
    private String rolesForTeam;
    @JsonProperty("stepName")
    private String stepName;
    @JsonProperty("taskType")
    private String taskType;
    @JsonProperty("uritemplate")
    private String uriTemplate;
    @JsonProperty("autoClaim")
    private boolean autoClaim;
    @JsonProperty("stepAutoClaim")
    private boolean stepAutoClaim;
    @JsonProperty("initiator")
    private boolean initiator;
    @JsonProperty("timerConfig")
    private TimerConfig timerConfig;
    @JsonProperty("uiAction")
    private List<UIAction> uiActions;
    @JsonProperty("buttonVisibilityType")
    private String buttonVisibilityType;
}
