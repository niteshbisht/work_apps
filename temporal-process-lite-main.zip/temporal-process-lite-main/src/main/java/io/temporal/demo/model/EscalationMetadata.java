package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EscalationMetadata {
    @JsonProperty("escalationStrategy")
    private String strategy;
    @JsonProperty("escalationStrategyData")
    private ArrayList<String> metadata;
    @JsonProperty("randomizeBy")
    private String randomizeBy;
    @JsonProperty("timeScheduleName")
    private String timeScheduleName;
    @JsonProperty("holidayScheduleName")
    private String holidayScheduleName;
}
