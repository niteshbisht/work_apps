package io.temporal.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessLiteConfig {
    @JsonProperty("category")
    private String category;
    @JsonProperty("subCategory")
    private String subCategory;
    @JsonProperty("workFlowType")
    private String workFlowType;
    @JsonProperty("workflowPriority")
    private String workflowPriority;
    @JsonProperty("appId")
    private String appId;
    @JsonProperty("initialAudit")
    private String initialAudit;
    @JsonProperty("initialStatus")
    private String initialStatus;
    @JsonProperty("initialstepName")
    private String initialStepName;
    @JsonProperty("timescheduleName")
    private String timescheduleName;
    @JsonProperty("releaseVersion")
    private String releaseVersion;
    @JsonProperty("folderDetails")
    private FolderDetails folderDetails;
    @JsonProperty("actions")
    private List<Action> actions;
    @JsonProperty("buttonVisibilityType")
    private String buttonVisibilityType;
    @JsonProperty("showInitialbocsInwidget")
    private boolean showInitialbocsInwidget;
    @JsonProperty("processAppId")
    private String processAppId;
    @JsonProperty("datashareStrategy")
    private String datashareStrategy;
    @JsonProperty("isGroupIdCorrelation")
    private boolean isGroupIdCorrelation;
    @JsonProperty("eprAppId")
    private String eprAppId;
    @JsonProperty("notifyConsumerType")
    private String notifyConsumerType;
    @JsonProperty("splashPageurl")
    private String splashPageurl;
}
