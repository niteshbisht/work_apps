package io.temporal.workflowstarter;

import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import io.temporal.demo.common.Constants;
import io.temporal.demo.model.*;
import io.temporal.workflow.Workflow;
import io.temporal.demo.workflow.ProcessLiteWorkflow;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class StartTheWorkflow implements CommandLineRunner {

    @Autowired
    private WorkflowClient client;

    public static void main(String[] args) {
        SpringApplication.run(StartTheWorkflow.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Logger log = Workflow.getLogger(StartTheWorkflow.class);
        log.info("Initiating the workflow..");

//        String suffix = RandomStringUtils.random(8, true, true);

        WorkflowOptions options = WorkflowOptions.newBuilder().
                setTaskQueue(Constants.TASK_QUEUE).
                setWorkflowId(Constants.WORKFLOW_ID).
                build();

        ProcessLiteWorkflow workflow = client.newWorkflowStub(ProcessLiteWorkflow.class, options);

        WorkflowConfiguration config = WorkflowConfiguration.builder()
                .configId(321)
                .appId("AppId")
                .category("WMADV")
                .subcategory("Fee")
                .processLiteConfig(ProcessLiteConfig.builder()
                        .category("WMADV")
                        .subCategory("Fee")
                        .workFlowType("Fee Waiver")
                        .workflowPriority("High")
                        .appId("BWF")
                        .initialAudit("Saved")
                        .initialStatus("Pending Submission")
                        .initialStepName("BSM/CBSO")
                        .timescheduleName("MS24X5TimeSchedule")
//                        .releaseVersion("2009")
//                        .folderDetails(FolderDetails.builder()
//                                .attachedFolderName("Documents")
//                                .transactionType("AIP")
//                                .allDocs(true)
//                                .build())
                        .actions(buildActions())
                        .showInitialbocsInwidget(false)
                        .processAppId("")
                        .datashareStrategy("")
                        .isGroupIdCorrelation(false)
                        .eprAppId("")
                        .notifyConsumerType("")
                        .splashPageurl("")
                        .build())
                .build();

        String result = workflow.execute(config);
        log.info("The response from the workflow {}",result);
        System.exit(0);
    }

    private List<Action> buildActions()
    {
        ArrayList<Action> actionList = new ArrayList<>();
        actionList.add(Action.builder()
                        .stepId("1")
                        .config(ActionConfig.builder()
                                .rolesForTeam("BWFBRMGR")
                                .stepName("BSM/CBSO")
                                .taskType("HUMAN")
                                .uriTemplate("/advfeewaiverui/#/")
                                .autoClaim(true)
                                .stepAutoClaim(true)
                                .initiator(true)
                                .timerConfig(TimerConfig.builder()
                                        .escalationRejectPeriod(129600L)
                                        .dueIn(72)
                                        .isDueDateCalculationRequired(true)
                                        .escalationMetadata(EscalationMetadata.builder()
                                                .strategy("")
                                                .metadata(new ArrayList<>())
                                                .build())
                                        .build())
                                .uiActions(buildUIActions())
                                .buttonVisibilityType("default")
                                .build())
                        .build());
        actionList.add(Action.builder()
                        .stepId("2")
                        .initialStatus("Pending Approval")
                        .initialStepName("RBSO/RMA")
                        .isNewApprovalProcessFlow(true)
                        .isEmailNoifyFlow(true)
                        .notificationType("email")
                        .config(ActionConfig.builder()
                                .rolesForTeam("BWFRKRBS,BWFBRMGR")
                                .stepName("Region")
                                .taskType("HUMAN")
                                .uriTemplate("/advfeewaiverui/#/")
                                .timerConfig(TimerConfig.builder()
                                        .escalationRejectPeriod(129600L)
                                        .dueIn(72)
                                        .isDueDateCalculationRequired(true)
                                        .escalationMetadata(EscalationMetadata.builder()
                                                .strategy("")
                                                .metadata(new ArrayList<>())
                                                .build())
                                        .build())
                                .uiActions(buildUIActionsForStep2())
                                .buttonVisibilityType("default")
                                .build())

                .build());

        actionList.add(Action.builder()
                .stepId("3")
                .config(ActionConfig.builder()
                        .rolesForTeam("BWFARP,BWFCRKOF,BWFBRMGR")
                        .stepName("Asset Retention Program Team")
                        .taskType("HUMAN")
                        .uriTemplate("/advfeewaiverui/#/")
                        .timerConfig(TimerConfig.builder()
                                .escalationRejectPeriod(129600L)
                                .dueIn(72)
                                .isDueDateCalculationRequired(true)
                                .escalationMetadata(EscalationMetadata.builder()
                                        .strategy("")
                                        .metadata(new ArrayList<>())
                                        .build())
                                .build())
                        .uiActions(buildUIActionsForStep3())
                        .buttonVisibilityType("default")
                        .build())
                .build());

        actionList.add(Action.builder()
                .stepId("4")
                .config(ActionConfig.builder()
                        .stepName("NOTIFYWORKFLOWCOMPLETION")
                        .taskType("SYSTEM")
                        .timerConfig(TimerConfig.builder()
                                .escalationRejectPeriod(129600L)
                                .dueIn(72)
                                .isDueDateCalculationRequired(true)
                                .escalationMetadata(EscalationMetadata.builder()
                                        .strategy("")
                                        .metadata(new ArrayList<>())
                                        .build())
                                .build())
                        .uiActions(buildUIActionsForStep4())
                        .timerConfig(TimerConfig.builder()
                                .escalationRejectPeriod(0)
                                .dueIn(0)
                                .dueDateService("")
                                .isLastBusinessDayDueIn(false)
                                .isExpirationSameAsDueDate(false)
                                .expirationService("")
                                .randomizeExpirationBy(0)
                                .dueDateTimeSchedule("")
                                .escalationMetadata(EscalationMetadata.builder()
                                        .strategy("")
                                        .metadata(new ArrayList<>())
                                        .randomizeBy("")
                                        .timeScheduleName("")
                                        .holidayScheduleName("")
                                        .build())
                                .build())
                        .buttonVisibilityType("default")
                        .build())
                .build());

        actionList.add(Action.builder()
                .stepId("5")
                .config(ActionConfig.builder()
                        .stepName("ARCHIVEPROCESS")
                        .taskType("SYSTEM")
                        .uriTemplate("/advfeewaiverui/#/")
                        .uiActions(new ArrayList<>())
                        .timerConfig(TimerConfig.builder()
                                .escalationRejectPeriod(0)
                                .dueIn(0)
                                .dueDateService("")
                                .isLastBusinessDayDueIn(false)
                                .isExpirationSameAsDueDate(false)
                                .expirationService("")
                                .randomizeExpirationBy(0)
                                .dueDateTimeSchedule("")
                                .escalationMetadata(EscalationMetadata.builder()
                                        .strategy("")
                                        .metadata(new ArrayList<>())
                                        .randomizeBy("")
                                        .timeScheduleName("")
                                        .holidayScheduleName("")
                                        .build())
                                .build())
                        .buttonVisibilityType("default")
                        .build())
                .build());

        return actionList;
    }

    private List<UIAction> buildUIActionsForStep4()
    {
        ArrayList<UIAction> actionList = new ArrayList<>();
        actionList.add(UIAction.builder()
                .action("Success")
                .stepId("5")
                .status(" ")
                .stepName(" ")
                .auditMessage("Fee waiver update applied successfully")
                .build());

        actionList.add(UIAction.builder()
                .action("Cancel")
                .stepId("5")
                .status("Cancelled")
                .stepName(" ")
                .auditMessage("Fee waiver not applied due to termination or update to the account and no longer qualifies for fee waiver")
                .build());
        return actionList;
    }

    private List<UIAction> buildUIActionsForStep3()
    {
        ArrayList<UIAction> actionList = new ArrayList<>();
        actionList.add(UIAction.builder()
                        .action("APPROVE")
                        .stepId("4")
                        .status("Approved")
                        .stepName(" ")
                        .auditMessage("Approved")
                .build());

        actionList.add(UIAction.builder()
                .action("REJECT")
                .stepId("5")
                .status("Rejected")
                .stepName(" ")
                .auditMessage("Rejected")
                .build());

        actionList.add(UIAction.builder()
                .action("CANCEL")
                .stepId("5")
                .status("Cancelled")
                .stepName(" ")
                .auditMessage("Cancelled")
                .build());

        actionList.add(UIAction.builder()
                .action("ESCALATIONREJECT")
                .stepId("5")
                .status("Expired")
                .stepName(" ")
                .auditMessage("Expired")
                .build());

        actionList.add(UIAction.builder()
                .action("CORRECT")
                .stepId("1")
                .status("Pend Correction")
                .stepName("BSM/CBSO")
                .auditMessage("Sent for correction")
                .build());
        return actionList;
    }

    private List<UIAction> buildUIActionsForStep2()
    {
        ArrayList<UIAction> actionList = new ArrayList<>();
        actionList.add(UIAction.builder()
                        .action("APPROVE")
                        .stepId("3")
                        .status("Pending Approval")
                        .stepName("Asset Retention Program Team")
                        .auditMessage("Approved")
                .build());

        actionList.add(UIAction.builder()
                .action("REJECT")
                .stepId("5")
                .status("Rejected")
                .stepName(" ")
                .auditMessage("Rejected")
                .build());

        actionList.add(UIAction.builder()
                .action("CANCEL")
                .stepId("5")
                .status("Cancelled")
                .stepName(" ")
                .auditMessage("Cancelled")
                .build());

        actionList.add(UIAction.builder()
                .action("ESCALATIONREJECT")
                .stepId("5")
                .status("Expired")
                .stepName(" ")
                .auditMessage("Expired")
                .build());

        actionList.add(UIAction.builder()
                .action("CORRECT")
                .stepId("1")
                .status("Pend Correction")
                .stepName("BSM/CBSO")
                .auditMessage("Sent for correction")
                .build());

        return actionList;
    }


    private List<UIAction> buildUIActions()
    {
        ArrayList<UIAction> actionList = new ArrayList<>();
        actionList.add(UIAction.builder()
                .action("SUBMIT")
                .stepId("2")
                .status("Pending Approval")
                .stepName("RBSO/RMA")
                .auditMessage("Submitted")
                .build());

        actionList.add(UIAction.builder()
                .action("CANCEL")
                .stepId("5")
                .status("Cancelled")
                .stepName(" ")
                .auditMessage("Cancelled")
                .build());

        actionList.add(UIAction.builder()
                .action("ESCALATIONREJECT")
                .stepId("5")
                .status("Expired")
                .stepName(" ")
                .auditMessage("Expired")
                .build());

        return actionList;
    }
}
