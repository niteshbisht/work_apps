# Process Lite

This is an example of how to use Temporal to navigate a JSON DSL. It uses a Spring Boot Console console application.

There are two applications in this repository. One to start the workers, and another one to initiate a workflow.

Note that Spring Boot Console apps cannot expose metrics, which are critical to a production deployment.

## Prerequisites
* [Temporal CLI](https://docs.temporal.io/cli#install)
* Java SDK
   
## Running Locally
Start Temporal Server locally
```shell
temporal server start-dev
```

To run the worker:

```shell
./gradlew bootRun
```

To run a workflow
```shell
./gradlew startWorkflow
```

This starts a workflow with a hard coded ID of "HelloProcessLite".

Now you can interact with the workflow by sending an update. For example

```shell
temporal workflow update execute --workflow-id HelloProcessLite --name signalWorkflow --input '"SUBMIT"'
```

Then you can advance the state by sending other "signals". In this example I'm sending an APPROVE.  

```shell
 temporal workflow update execute --workflow-id HelloProcessLite --name signalWorkflow --input '"APPROVE"'
```

And finally, to complete the workflow, send another approve

```shell
temporal workflow update execute --workflow-id HelloProcessLite --name signalWorkflow --input '"APPROVE"'
```

To run the two test cases 

```shell
./gradlew test
```
