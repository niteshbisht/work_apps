#!/bin/bash
if [ -z "$1" ]
  then
    echo "Missing signal input. Please specify the signal type (e.g. SUBMIT, CANCEL, APPROVE, REJECT)"
fi
echo "Signaling workflow with $1"
temporal workflow update execute --workflow-id HelloProcessLite --name signalWorkflow --input "$1"